--[[
-- Add the libs directory to the package path
package.path = package.path .. ";../libs/?.lua;../libs/?/init.lua"

-- Load and initialize the nest library for 3DS mode
require("nest").init({
    console = "3ds",  -- Enable 3DS mode
    scale = 1,        -- Scale the window size (1x by default)
    emulateJoystick = true  -- Enable joystick emulation via keyboard
})


require("nest").init({
    console = "3ds",  -- Enable 3DS mode
    scale = 1,        -- Scale the window size (1x by default)
    emulateJoystick = true  -- Enable joystick emulation via keyboard
})
--]]

function love.load()
    -- Load assets and initialize game state here
    -- love.graphics.set3D(false)
end

function love.update(dt)
    -- Update game logic here
end

function love.draw(screen)
    if screen ~= "bottom" then
        local width, height = love.graphics.getDimensions(screen)
        love.graphics.print("Hello World!", width / 2, height / 2)
    elseif screen ~= "left" then
        local width, height = love.graphics.getDimensions(screen)
        love.graphics.print("Welcome to the 3DS!", width / 2, height / 2)
    end
end

function love.gamepadpressed(joystick, button)
    love.event.quit()
end