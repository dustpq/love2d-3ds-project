-- Configuration file for the game

function love.conf(t)
    t.window.title = "if you see this, something went wrong"
    t.window.width = 400
    t.window.height = 240
end