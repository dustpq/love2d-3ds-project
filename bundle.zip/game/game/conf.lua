-- Configuration file for the game

function love.conf(t)
    t.window.title = "My 3DS Game"
    t.window.width = 400
    t.window.height = 240
end